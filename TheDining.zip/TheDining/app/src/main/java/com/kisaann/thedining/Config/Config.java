package com.kisaann.thedining.Config;

public class Config {
    public static String message = "";
    public static String title = "";
    public static String imageLink = "";
}
