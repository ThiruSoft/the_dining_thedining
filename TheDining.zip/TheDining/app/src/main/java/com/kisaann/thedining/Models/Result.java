package com.kisaann.thedining.Models;

public class Result {
    public String message_id;
}
