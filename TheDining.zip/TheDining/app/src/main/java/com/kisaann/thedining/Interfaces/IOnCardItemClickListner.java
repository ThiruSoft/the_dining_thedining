package com.kisaann.thedining.Interfaces;

import android.view.View;

public interface IOnCardItemClickListner {
    void onCardItemClick(View view, int position);
}
