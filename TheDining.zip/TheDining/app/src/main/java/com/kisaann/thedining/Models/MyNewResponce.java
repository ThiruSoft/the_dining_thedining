package com.kisaann.thedining.Models;

public class MyNewResponce {
    public int success;
}
